// https://github.com/element-plus/element-plus/issues/4855

import 'element-plus/dist/index.css'
import 'element-plus/theme-chalk/display.css'

export function setup() {}
