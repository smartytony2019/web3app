<script lang="ts" setup></script>

<template>
  <vab-card class="store-left" shadow="hover">
    <vab-icon icon="apps-2-line" />
    敬请期待

    <el-empty class="vab-data-empty" description="暂无数据" />
  </vab-card>
</template>

<style lang="scss" scoped>
  .store-left {
  }
</style>
