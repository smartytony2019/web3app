import VabMagnifier from 'magnifier-vue3'
import 'magnifier-vue3/lib/magnifier-vue3.css'

export default VabMagnifier
