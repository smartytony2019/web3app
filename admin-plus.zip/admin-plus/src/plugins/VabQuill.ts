import 'quill-vue3/lib/quill-vue3.css'
import VabQuill from 'quill-vue3'

export default VabQuill
