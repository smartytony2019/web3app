import VabCount from 'count-vue3'

export default VabCount
