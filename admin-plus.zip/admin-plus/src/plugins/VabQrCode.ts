import VabQrCode from 'vue-qr/src/packages/vue-qr.vue'

export default VabQrCode
