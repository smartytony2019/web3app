<template>
  <vab-app />
</template>
