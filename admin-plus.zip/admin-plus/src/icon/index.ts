const icons = require.context('.', true, /\.svg$/)
icons.keys().map(icons)
